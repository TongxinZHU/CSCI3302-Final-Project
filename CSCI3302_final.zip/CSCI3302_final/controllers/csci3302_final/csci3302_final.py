"""csci3302_final controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
import math
import time
import numpy as np
from controller import Robot, Motor, DistanceSensor
import csci3302_final_supervisor
from scipy import stats
from math import sqrt
from math import atan2
from math import degrees

# These are your pose values that you will update by solving the odometry equations
pose_x = 0
pose_y = 0
pose_theta = 0

# Constants to help with the Odometry update
WHEEL_FORWARD = 1
WHEEL_STOPPED = 0
WHEEL_BACKWARD = -1

# create the Robot instance.
csci3302_final_supervisor.init_supervisor()
robot = csci3302_final_supervisor.supervisor

EPUCK_MAX_WHEEL_SPEED = 0.12880519 # Unnecessarily precise ePuck speed in m/s. REMINDER: motor.setVelocity() takes ROTATIONS/SEC as param, not m/s.
EPUCK_AXLE_DIAMETER = 0.053 # ePuck's wheels are 53mm apart.
EPUCK_WHEEL_RADIUS = 0.0205 # ePuck's wheels are 0.041m in diameter.

# get the time step of the current world.
SIM_TIMESTEP = int(robot.getBasicTimeStep())

# Initialize Motors
leftMotor = robot.getMotor('left wheel motor')
rightMotor = robot.getMotor('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# initialize Sensors
right_sensor_readings = [0, 0, 0, 0]
left_sensor_readings = [0, 0, 0, 0]
SENSOR_THRESHOLD = [75, 75, 75, 75]

right_sensors = [robot.getDistanceSensor('ps0'), robot.getDistanceSensor('ps1'), robot.getDistanceSensor('ps2'), robot.getDistanceSensor('ps3')]
left_sensors = [robot.getDistanceSensor('ps4'), robot.getDistanceSensor('ps5'), robot.getDistanceSensor('ps6'), robot.getDistanceSensor('ps7')]
for ps in right_sensors:
    ps.enable(SIM_TIMESTEP)
for ps in left_sensors:
    ps.enable(SIM_TIMESTEP)

def get_bounded_theta(theta):
    '''
    Returns theta bounded in [-PI, PI]
    '''
    while theta > math.pi: theta -= 2.*math.pi
    while theta < -math.pi: theta += 2.*math.pi
    return theta

'''
error function
'''
def error_checker(error):
    if abs(error) > 0.05:
        return True
    else:
        return False
        
state = "object_avoidance"

def main():
    global robot, state
    global right_sensor_readings, left_sensor_readings, RIGHT_SENSOR_THRESHOLD, LEFT_SENSOR_THRESHOLD, right_sensors, left_sensors
    global leftMotor, rightMotor, SIM_TIMESTEP, WHEEL_FORWARD, WHEEL_STOPPED, WHEEL_BACKWARD
    global pose_x, pose_y, pose_theta

    # Keep track of which direction each wheel is turning
    right_wheel_direction = WHEEL_STOPPED
    left_wheel_direction = WHEEL_STOPPED

    # Important IK Variable storing final desired pose
    target_pose = None # Populated by the supervisor, only when the target is moved.

    # Sensor burn-in period
    for i in range(10): robot.step(SIM_TIMESTEP)
    
    # Main Control Loop:
    while robot.step(SIM_TIMESTEP) != -1:
        # Robot pose
        current_pose = csci3302_final_supervisor.supervisor_get_robot_pose()
        pose_x = current_pose[0]
        pose_y = current_pose[1]
        pose_theta = current_pose[2]

        # Get target location -- do not modify
        if target_pose is None:
            target_pose = csci3302_final_supervisor.supervisor_get_target_pose()
            print("New IK Goal Received! Target: %s" % str(target_pose))

        # Your code starts here
        bearing = atan2((target_pose[1] - pose_y), (target_pose[0] - pose_x))
        bearing_error = atan2((target_pose[1] - pose_y), (target_pose[0] - pose_x)) - pose_theta + math.pi
        distance_error = sqrt(pow(target_pose[0] - pose_x, 2) + pow(target_pose[1] - pose_y, 2))
        
        #Assign obstable detection
        right_sensor_readings = [r.getValue() for r in right_sensors]
        left_sensor_readings = [l.getValue() for l in left_sensors]
        
        right_obstacle = [(x > y) for x, y in zip(right_sensor_readings, SENSOR_THRESHOLD)]
        left_obstacle = [(m > n) for m, n in zip(left_sensor_readings, SENSOR_THRESHOLD)]
            
        b = error_checker(bearing_error)
        d = error_checker(distance_error)
        
        #start light section
        a_pose, b_pose, c_pose = csci3302_final_supervisor.supervisor_get_light_pose()
        a_state, b_state, c_state = csci3302_final_supervisor.supervisor_get_light_state()
        
        a_dis = sqrt(pow(a_pose[0] - pose_x, 2) + pow(a_pose[1] - pose_y, 2))
        b_dis = sqrt(pow(b_pose[0] - pose_x, 2) + pow(b_pose[1] - pose_y, 2))
        c_dis = sqrt(pow(c_pose[0] - pose_x, 2) + pow(c_pose[1] - pose_y, 2))
        
        if min(a_dis, b_dis, c_dis) < 0.15:
            state = "stop"
        elif True in left_obstacle or True in right_obstacle:
            state = "object_avoidance"
        else:
            state = "reach_goal"

        #end light section
        
        rightMotor.setVelocity(rightMotor.getMaxVelocity() / 12.0)
        leftMotor.setVelocity(leftMotor.getMaxVelocity() / 12.0)
        
        if state == "reach_goal":
            if b is True:
                if abs(bearing_error) > 0.05:
                    rightMotor.setVelocity(rightMotor.getMaxVelocity() / 12.0)
                    leftMotor.setVelocity(-leftMotor.getMaxVelocity() / 12.0)
                    right_wheel_direction = WHEEL_FORWARD / 12.0
                    left_wheel_direction = WHEEL_BACKWARD / 12.0
                else:
                    rightMotor.setVelocity(0.0)
                    leftMotor.setVelocity(0.0)
                    right_wheel_direction = WHEEL_STOPPED
                    left_wheel_direction = WHEEL_STOPPED
                    b = False
            elif b is False and d is True:
                if abs(distance_error) > 0.05:
                    rightMotor.setVelocity(rightMotor.getMaxVelocity() / 12.0)
                    leftMotor.setVelocity(leftMotor.getMaxVelocity() / 12.0)
                    right_wheel_direction = WHEEL_FORWARD / 12.0
                    left_wheel_direction = WHEEL_FORWARD / 12.0
                else:
                    rightMotor.setVelocity(0.0)
                    leftMotor.setVelocity(0.0)
                    right_wheel_direction = WHEEL_STOPPED
                    left_wheel_direction = WHEEL_STOPPED
                    d = False
            else:
                state = "finish"
        if state == "object_avoidance":
            if True in right_obstacle:
                rightMotor.setVelocity(rightMotor.getMaxVelocity() / 12.0)
                leftMotor.setVelocity(-leftMotor.getMaxVelocity() / 12.0)
            elif True in left_obstacle:
                rightMotor.setVelocity(-rightMotor.getMaxVelocity() / 12.0)
                leftMotor.setVelocity(leftMotor.getMaxVelocity() / 12.0)
        if state == "stop":
            if a_state == "red" or b_state == "red" or c_state == "red":
                rightMotor.setVelocity(0.0)
                leftMotor.setVelocity(0.0)
                right_wheel_direction = WHEEL_STOPPED
                left_wheel_direction = WHEEL_STOPPED
            else:
                state = "reach_goal"
                pass
                
        if state == "finish":
            SIM_TIMESTEP = -1
            pass

        print(state)
        # To help you debug! Feel free to comment out.
        #print("Current pose: [%5f, %5f, %5f]\t\t Target pose: [%5f, %5f, %5f]\t\t Errors: [%5f, %5f, %5f]" % (pose_x, pose_y, pose_theta, target_pose[0], target_pose[1], target_pose[2],bearing_error, distance_error, heading_error))
    
if __name__ == "__main__":
    main()

