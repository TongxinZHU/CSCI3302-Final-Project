"""supervisor controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
import copy
import sys
from controller import Supervisor
import numpy as np

supervisor = None
robot_node = None
target_node = None
A_node = None
B_node = None
C_node = None

def init_supervisor():
    global supervisor, robot_node, target_node, A_node, B_node, C_node
    supervisor = Supervisor()

    # do this once only
    robot_node = supervisor.getFromDef("EPUCK")
    target_node = supervisor.getFromDef("Goal")
    A_node = supervisor.getFromDef("lightA")
    B_node = supervisor.getFromDef("lightB")
    C_node = supervisor.getFromDef("lightC")
    if robot_node is None:
        sys.stderr.write("No DEF e-puck node found in the current world file\n")
        sys.exit(1)

def supervisor_get_target_pose():
    global supervisor, robot_node, target_node, A_node, B_node, C_node
    '''
    Returns target position relative to the robot's current position.
    Do not call during your solution! Only during problem setup and for debugging!
    '''
    # Webots -X = Robot Y
    # Webots -Z = Robot X
    # Webots theta = Robot Theta
    target_position = np.array(target_node.getField("translation").getSFVec3f())
    target_pose = np.array([target_position[0], target_position[2]])
    # print("Target pose relative to robot: %s" % (str(target_pose)))
    return target_pose

def supervisor_get_robot_pose():
    global supervisor, robot_node, target_node, A_node, B_node, C_node
    """
    Returns robot position
    """
    robot_position = np.array(robot_node.getField("translation").getSFVec3f())
    robot_pose = np.array([robot_position[0], robot_position[2], robot_node.getField("rotation").getSFRotation()[3]])

    return robot_pose
    
def supervisor_get_light_pose():
    global supervisor, robot_node, target_node, A_node, B_node, C_node
    """
    Returns light position
    """
    A_position = np.array(A_node.getField("translation").getSFVec3f())
    A_pose = np.array([A_position[0], A_position[2]])

    B_position = np.array(B_node.getField("translation").getSFVec3f())
    B_pose = np.array([B_position[0], B_position[2]])
    
    C_position = np.array(C_node.getField("translation").getSFVec3f())
    C_pose = np.array([C_position[0], C_position[2]])

    return A_pose, B_pose, C_pose
    
def supervisor_get_light_state():
    global supervisor, robot_node, target_node, lightA_node, lightB_node, lightC_node
    """
    Returns light state
    """
    A_state = A_node.getField("state").getSFString()
    B_state = A_node.getField("state").getSFString()
    C_state = A_node.getField("state").getSFString()

    return A_state, B_state, C_state

